Requirements:
python 3.9
flask 3.0.3
tensorflow 2.15.0
numpy 1.23.5
pillow 10.3.0

To run the server, run the following command:
python app.py
or
flask run

Open you browser on:
http://localhost:5000/
http://127.0.0.1:5000/